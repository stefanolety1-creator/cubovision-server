// routes/liveTv.js
import { Router } from "express";
import { streamResolver } from "../services/streamResolver.js";

const router = Router();

// GET /api/live/channels
// Restituisce tutti i canali con le relative variazioni di stream
router.get("/channels", (req, res) => {
  const channels = streamResolver.getLiveChannels();
  res.json({
    status: "ok",
    count: channels.length,
    data: channels
  });
});

// GET /api/live/channels/:id
// Dettaglio canale specifico con tutte le variazioni
router.get("/channels/:id", (req, res) => {
  const channel = streamResolver.getChannelById(req.params.id);
  if (!channel) {
    return res.status(404).json({ status: "error", message: "Canale non trovato" });
  }
  res.json({
    status: "ok",
    data: channel
  });
});

// GET /api/live/play/:id?var=0
// Risolve direttamente la variazione richiesta oppure fa redirect allo stream attivo
router.get("/play/:id", (req, res) => {
  const varIndex = req.query.var || 0;
  const resolved = streamResolver.resolveChannelStream(req.params.id, varIndex);

  if (!resolved || !resolved.stream) {
    return res.status(404).json({ status: "error", message: "Stream per il canale non disponibile" });
  }

  // Se il client chiede JSON
  if (req.query.format === "json") {
    return res.json({
      status: "ok",
      data: resolved
    });
  }

  // Altrimenti reindirizza direttamente al flusso video attivo
  res.redirect(302, resolved.stream.url);
});

export default router;
