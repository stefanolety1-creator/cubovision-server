// routes/sports.js
import { Router } from "express";
import { streamResolver } from "../services/streamResolver.js";

const router = Router();

// GET /api/sports/events
// Elenco eventi sportivi con punteggi, stato LIVE e relative variazioni di sorgenti
router.get("/events", async (req, res) => {
  try {
    const events = await streamResolver.getSportsEvents();
    res.json({
      status: "ok",
      count: events.length,
      data: events
    });
  } catch (err) {
    res.status(500).json({ status: "error", message: err.message });
  }
});

// GET /api/sports/events/:id
// Dettaglio evento sportivo con lista di tutte le variazioni (Server 1, Server 2...)
router.get("/events/:id", (req, res) => {
  const sport = streamResolver.getSportById(req.params.id);
  if (!sport) {
    return res.status(404).json({ status: "error", message: "Evento sportivo non trovato" });
  }
  res.json({
    status: "ok",
    data: sport
  });
});

// GET /api/sports/play/:id?var=0
// Risolve la variazione e fa redirect o restituisce lo stream selezionato
router.get("/play/:id", (req, res) => {
  const varIndex = req.query.var || 0;
  const resolved = streamResolver.resolveSportStream(req.params.id, varIndex);

  if (!resolved || !resolved.stream) {
    return res.status(404).json({ status: "error", message: "Flusso sportivo non disponibile" });
  }

  if (req.query.format === "json") {
    return res.json({
      status: "ok",
      data: resolved
    });
  }

  // Redirect diretto allo stream video selezionato
  res.redirect(302, resolved.stream.url);
});

export default router;
