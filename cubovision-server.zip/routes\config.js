// routes/config.js
import { Router } from "express";
import { streamResolver } from "../services/streamResolver.js";

const router = Router();

// GET /api/config
// Restituisce la configurazione generale per l'app Android Cubovision
router.get("/", (req, res) => {
  const config = streamResolver.getConfig();
  res.json({
    status: "ok",
    data: config
  });
});

export default router;
