// services/streamResolver.js
// Gestore unificato di tutte le API esterne e delle VARIAZIONI di stream

import { initialSources } from "../config/sources.js";
import { cacheService } from "./cacheService.js";

class StreamResolver {
  constructor() {
    // Stato sorgenti modificabile a runtime
    this.appConfig = { ...initialSources.appConfig };
    this.liveChannels = JSON.parse(JSON.stringify(initialSources.liveChannels));
    this.sportsEvents = JSON.parse(JSON.stringify(initialSources.sportsEvents));
    this.vodProviders = JSON.parse(JSON.stringify(initialSources.vodProviders));
  }

  // --- CONFIGURAZIONE ---
  getConfig() {
    return {
      ...this.appConfig,
      stats: {
        totalChannels: this.liveChannels.length,
        totalSportsEvents: this.sportsEvents.length,
        vodProvidersCount: this.vodProviders.length,
        uptimeSeconds: Math.floor(process.uptime())
      }
    };
  }

  updateConfig(patch) {
    this.appConfig = { ...this.appConfig, ...patch };
    return this.appConfig;
  }

  // --- CANALI LIVE TV E VARIAZIONI ---
  getLiveChannels() {
    return this.liveChannels;
  }

  getChannelById(channelId) {
    return this.liveChannels.find((ch) => ch.id.toLowerCase() === channelId.toLowerCase());
  }

  resolveChannelStream(channelId, variationIndex = 0) {
    const channel = this.getChannelById(channelId);
    if (!channel) return null;

    if (!channel.variations || channel.variations.length === 0) {
      return null;
    }

    const index = Math.min(Math.max(0, parseInt(variationIndex, 10) || 0), channel.variations.length - 1);
    const selected = channel.variations[index];

    return {
      channelId: channel.id,
      channelName: channel.name,
      variationIndex: index,
      totalVariations: channel.variations.length,
      stream: selected,
      allVariations: channel.variations
    };
  }

  // --- EVENTI SPORT E VARIAZIONI ---
  async getSportsEvents() {
    // 1. Se è configurata una SPORT_API esterna, prova a interrogarla con cache
    const externalUrl = process.env.SPORT_API_BASE_URL;
    if (externalUrl) {
      const cacheKey = "external_sports_feed";
      const cached = cacheService.get(cacheKey);
      if (cached) return cached;

      try {
        const headers = {};
        if (process.env.SPORT_API_KEY) {
          headers["Authorization"] = `Bearer ${process.env.SPORT_API_KEY}`;
          headers["x-api-key"] = process.env.SPORT_API_KEY;
        }

        const res = await fetch(externalUrl, { headers, signal: AbortSignal.timeout(5000) });
        if (res.ok) {
          const raw = await res.json();
          // Normalizziamo l'output esterno e fondiamo con gli eventi locali
          const externalNormalized = this.normalizeExternalSport(raw);
          const combined = [...externalNormalized, ...this.sportsEvents];
          cacheService.set(cacheKey, combined, 30); // 30s cache per il live
          return combined;
        }
      } catch (err) {
        console.warn("[StreamResolver] Errore fetch Sport API esterna, uso fallback locale:", err.message);
      }
    }

    // 2. Fallback su eventi interni con variazioni
    return this.sportsEvents;
  }

  normalizeExternalSport(data) {
    if (!Array.isArray(data)) {
      if (data && Array.isArray(data.events)) data = data.events;
      else if (data && Array.isArray(data.matches)) data = data.matches;
      else return [];
    }

    return data.map((item, idx) => ({
      id: item.id || `ext_sport_${idx}`,
      title: item.title || item.name || `${item.homeTeam || "Team A"} vs ${item.awayTeam || "Team B"}`,
      sport: item.sport || "Sport",
      tournament: item.league || item.tournament || "Campionato",
      status: (item.status || "LIVE").toUpperCase(),
      startTime: item.time || item.startTime || "Live",
      date: item.date || "Oggi",
      score: item.score || item.currentScore || "-",
      minute: item.minute || "Live",
      poster: item.poster || item.thumbnail || "https://images.unsplash.com/photo-1508098682722-e99c43a406b2?w=600",
      variations: Array.isArray(item.streams) && item.streams.length > 0
        ? item.streams.map((s, sIdx) => ({
            name: s.name || `Variazione ${sIdx + 1}`,
            type: s.type || (s.url && s.url.includes(".m3u8") ? "hls" : "embed"),
            url: s.url,
            priority: sIdx + 1
          }))
        : [
            {
              name: "Stream Principale",
              type: item.url && item.url.includes(".m3u8") ? "hls" : "embed",
              url: item.url || item.streamUrl || "",
              priority: 1
            }
          ]
    }));
  }

  getSportById(sportId) {
    return this.sportsEvents.find((ev) => ev.id.toLowerCase() === sportId.toLowerCase());
  }

  resolveSportStream(sportId, variationIndex = 0) {
    const sport = this.getSportById(sportId);
    if (!sport) return null;

    if (!sport.variations || sport.variations.length === 0) {
      return null;
    }

    const index = Math.min(Math.max(0, parseInt(variationIndex, 10) || 0), sport.variations.length - 1);
    const selected = sport.variations[index];

    return {
      eventId: sport.id,
      title: sport.title,
      tournament: sport.tournament,
      variationIndex: index,
      totalVariations: sport.variations.length,
      stream: selected,
      allVariations: sport.variations
    };
  }

  // --- GESTIONE VARIAZIONI RUNTIME (Aggiornamenti a caldo) ---
  addOrUpdateChannel(channel) {
    const idx = this.liveChannels.findIndex((c) => c.id === channel.id);
    if (idx >= 0) {
      this.liveChannels[idx] = { ...this.liveChannels[idx], ...channel };
    } else {
      this.liveChannels.push(channel);
    }
    return this.liveChannels;
  }

  addOrUpdateSport(sportEvent) {
    const idx = this.sportsEvents.findIndex((e) => e.id === sportEvent.id);
    if (idx >= 0) {
      this.sportsEvents[idx] = { ...this.sportsEvents[idx], ...sportEvent };
    } else {
      this.sportsEvents.unshift(sportEvent);
    }
    return this.sportsEvents;
  }

  setVariations(type, id, variationsList) {
    if (type === "channel") {
      const ch = this.getChannelById(id);
      if (ch) {
        ch.variations = variationsList;
        return ch;
      }
    } else if (type === "sport") {
      const sp = this.getSportById(id);
      if (sp) {
        sp.variations = variationsList;
        return sp;
      }
    }
    return null;
  }
}

export const streamResolver = new StreamResolver();
