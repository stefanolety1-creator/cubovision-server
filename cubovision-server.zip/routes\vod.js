// routes/vod.js
import { Router } from "express";
import { cacheService } from "../services/cacheService.js";

const router = Router();
const OMDB_KEY = process.env.OMDB_API_KEY || "fdce1a3b";
const OMDB_BASE = "https://www.omdbapi.com/";

// GET /api/vod/search?q=Inception
router.get("/search", async (req, res) => {
  const query = req.query.q;
  if (!query) {
    return res.status(400).json({ status: "error", message: "Parametro 'q' mancante" });
  }

  const cacheKey = `omdb_search_${query.toLowerCase()}`;
  const cached = cacheService.get(cacheKey);
  if (cached) {
    return res.json({ status: "ok", cached: true, data: cached });
  }

  try {
    const url = `${OMDB_BASE}?apikey=${OMDB_KEY}&s=${encodeURIComponent(query)}`;
    const omdbRes = await fetch(url, { signal: AbortSignal.timeout(5000) });
    const data = await omdbRes.json();

    if (data.Response === "True") {
      cacheService.set(cacheKey, data.Search, 300); // 5 minuti
      return res.json({ status: "ok", data: data.Search });
    } else {
      return res.status(404).json({ status: "error", message: data.Error || "Nessun risultato" });
    }
  } catch (err) {
    return res.status(500).json({ status: "error", message: err.message });
  }
});

// GET /api/vod/details/:imdbId
router.get("/details/:imdbId", async (req, res) => {
  const imdbId = req.params.imdbId;
  const cacheKey = `omdb_detail_${imdbId}`;
  const cached = cacheService.get(cacheKey);
  if (cached) {
    return res.json({ status: "ok", cached: true, data: cached });
  }

  try {
    const url = `${OMDB_BASE}?apikey=${OMDB_KEY}&i=${imdbId}&plot=full`;
    const omdbRes = await fetch(url, { signal: AbortSignal.timeout(5000) });
    const data = await omdbRes.json();

    if (data.Response === "True") {
      // Aggiungiamo anche le variazioni di streaming disponibili
      const isMovie = data.Type === "movie";
      const enriched = {
        ...data,
        streamVariations: [
          {
            name: "Server Primario (VixSrc)",
            type: "embed",
            url: isMovie ? `https://vixsrc.to/movie/${imdbId}` : `https://vixsrc.to/tv/${imdbId}/1/1`
          },
          {
            name: "Server Mirror (VixCloud)",
            type: "embed",
            url: isMovie ? `https://vixcloud.co/movie/${imdbId}` : `https://vixcloud.co/tv/${imdbId}/1/1`
          }
        ]
      };

      cacheService.set(cacheKey, enriched, 3600); // 1 ora
      return res.json({ status: "ok", data: enriched });
    } else {
      return res.status(404).json({ status: "error", message: data.Error || "Dettaglio non trovato" });
    }
  } catch (err) {
    return res.status(500).json({ status: "error", message: err.message });
  }
});

export default router;
