// config/sources.js
// Cubovision Catalogo Sorgenti, Canali TV e Variazioni Flussi

export const initialSources = {
  // Configurazione globale inviata all'app Cubovision
  appConfig: {
    appName: "Cubovision",
    serverVersion: "1.0.0",
    theme: "TELECOM_2009_RED_BLACK",
    motd: "Benvenuto su Cubovision Telecom Italia",
    features: {
      liveTvEnabled: true,
      sportsEnabled: true,
      vodEnabled: true,
      remoteShortcuts: true,
      variationsSwitching: true
    }
  },

  // Canali TV Live con VARIAZIONI (flussi principali + fallback)
  liveChannels: [
    {
      id: "rai1",
      name: "Rai 1",
      number: 1,
      category: "Generalisti",
      logo: "https://upload.wikimedia.org/wikipedia/commons/thumb/e/e6/Rai_1_logo_%282016%29.svg/320px-Rai_1_logo_%282016%29.svg.png",
      description: "Primo canale del servizio pubblico televisivo italiano.",
      variations: [
        {
          name: "Primaria HD",
          type: "hls",
          url: "https://mediapolis.rai.it/relinker/relinkerServlet.htm?cont=2606803",
          priority: 1
        },
        {
          name: "Variazione Backup 1",
          type: "hls",
          url: "https://b2http.akamaized.net/hls/live/2038243/rai1/rai1.m3u8",
          priority: 2
        }
      ]
    },
    {
      id: "rai2",
      name: "Rai 2",
      number: 2,
      category: "Generalisti",
      logo: "https://upload.wikimedia.org/wikipedia/commons/thumb/9/91/Rai_2_logo_%282016%29.svg/320px-Rai_2_logo_%282016%29.svg.png",
      description: "Secondo canale Rai dedicato a intrattenimento, sport e serie.",
      variations: [
        {
          name: "Primaria HD",
          type: "hls",
          url: "https://mediapolis.rai.it/relinker/relinkerServlet.htm?cont=308732",
          priority: 1
        }
      ]
    },
    {
      id: "rai3",
      name: "Rai 3",
      number: 3,
      category: "Generalisti",
      logo: "https://upload.wikimedia.org/wikipedia/commons/thumb/d/d4/Rai_3_logo_%282016%29.svg/320px-Rai_3_logo_%282016%29.svg.png",
      description: "Terzo canale Rai incentrato su informazione e cultura.",
      variations: [
        {
          name: "Primaria HD",
          type: "hls",
          url: "https://mediapolis.rai.it/relinker/relinkerServlet.htm?cont=308734",
          priority: 1
        }
      ]
    },
    {
      id: "la7",
      name: "TG LA7 / LA7",
      number: 7,
      category: "Informazione",
      logo: "https://upload.wikimedia.org/wikipedia/commons/thumb/0/02/LA7_logo_%282011%29.svg/320px-LA7_logo_%282011%29.svg.png",
      description: "Canale di informazione e approfondimento Telecom Italia Media.",
      variations: [
        {
          name: "Primaria HLS",
          type: "hls",
          url: "https://d15umi5iaezxgx.cloudfront.net/LA7/LIVE/la7_live.m3u8",
          priority: 1
        }
      ]
    },
    {
      id: "sportitalia",
      name: "Sportitalia HD",
      number: 60,
      category: "Sport",
      logo: "https://upload.wikimedia.org/wikipedia/commons/thumb/f/f6/Sportitalia_logo_2019.svg/320px-Sportitalia_logo_2019.svg.png",
      description: "Tutto lo sport 24 ore su 24: calcio, motori, basket.",
      variations: [
        {
          name: "Primaria HD",
          type: "hls",
          url: "https://sportitalia.akamaized.net/hls/live/2034931/live1/playlist.m3u8",
          priority: 1
        },
        {
          name: "Variazione SD / Mobile",
          type: "hls",
          url: "https://sportitalia.akamaized.net/hls/live/2034931/live1/playlist_low.m3u8",
          priority: 2
        }
      ]
    },
    {
      id: "supertennis",
      name: "SuperTennis HD",
      number: 64,
      category: "Sport",
      logo: "https://upload.wikimedia.org/wikipedia/commons/thumb/c/cd/SuperTennis_logo.svg/320px-SuperTennis_logo.svg.png",
      description: "Il grande tennis in diretta: tornei ATP, WTA e Davis Cup.",
      variations: [
        {
          name: "Primaria HD",
          type: "hls",
          url: "https://supertennix.akamaized.net/hls/live/2034932/live/stream.m3u8",
          priority: 1
        }
      ]
    }
  ],

  // Eventi Sportivi con gestione VARIAZIONI (Server 1, Server 2, Server 3, HD, SD)
  sportsEvents: [
    {
      id: "sport_match_01",
      title: "Serie A: Inter vs Juventus",
      sport: "Calcio",
      tournament: "Serie A TIM",
      status: "LIVE", // UPCOMING, LIVE, FINISHED
      startTime: "20:45",
      date: "Oggi",
      score: "1 - 1",
      minute: "68'",
      poster: "https://images.unsplash.com/photo-1508098682722-e99c43a406b2?w=600&auto=format&fit=crop&q=80",
      variations: [
        {
          name: "Server 1 (HLS 1080p 50fps)",
          type: "hls",
          url: "https://test-streams.mux.dev/x36xhzz/x36xhzz.m3u8",
          priority: 1,
          bitrate: "6000k"
        },
        {
          name: "Server 2 (HLS 720p Backup)",
          type: "hls",
          url: "https://test-streams.mux.dev/x36xhzz/url_2/193039199_mp4_h264_aac_hd_7.m3u8",
          priority: 2,
          bitrate: "3000k"
        },
        {
          name: "Server 3 (Embed Web)",
          type: "embed",
          url: "https://vixsrc.to/tv/tt0903747/1/1",
          priority: 3
        }
      ]
    },
    {
      id: "sport_match_02",
      title: "Champions League: Real Madrid vs Bayern Monaco",
      sport: "Calcio",
      tournament: "UEFA Champions League",
      status: "LIVE",
      startTime: "21:00",
      date: "Oggi",
      score: "2 - 0",
      minute: "34'",
      poster: "https://images.unsplash.com/photo-1522778119026-d647f0596c20?w=600&auto=format&fit=crop&q=80",
      variations: [
        {
          name: "Server 1 (HLS Ultra)",
          type: "hls",
          url: "https://test-streams.mux.dev/x36xhzz/x36xhzz.m3u8",
          priority: 1
        },
        {
          name: "Server 2 (Mirror HLS)",
          type: "hls",
          url: "https://test-streams.mux.dev/x36xhzz/url_2/193039199_mp4_h264_aac_hd_7.m3u8",
          priority: 2
        }
      ]
    },
    {
      id: "sport_match_03",
      title: "Formula 1: Gran Premio di Monza - Gara",
      sport: "Motori",
      tournament: "FIA Formula 1 World Championship",
      status: "UPCOMING",
      startTime: "15:00",
      date: "Domenica",
      score: "-",
      minute: "Ore 15:00",
      poster: "https://images.unsplash.com/photo-1568605117036-5fe5e7bab0b7?w=600&auto=format&fit=crop&q=80",
      variations: [
        {
          name: "Canale Sky Sport F1 (Feed 1)",
          type: "hls",
          url: "https://test-streams.mux.dev/x36xhzz/x36xhzz.m3u8",
          priority: 1
        }
      ]
    },
    {
      id: "sport_match_04",
      title: "Tennis: Finale Wimbledon Singolare Maschile",
      sport: "Tennis",
      tournament: "Wimbledon Championship",
      status: "LIVE",
      startTime: "16:00",
      date: "Oggi",
      score: "6-4, 4-6, 5-3",
      minute: "Set 3",
      poster: "https://images.unsplash.com/photo-1595435934249-5df7ed86e1c0?w=600&auto=format&fit=crop&q=80",
      variations: [
        {
          name: "Flusso 1 (Campo Centrale HD)",
          type: "hls",
          url: "https://test-streams.mux.dev/x36xhzz/x36xhzz.m3u8",
          priority: 1
        }
      ]
    }
  ],

  // Fornitori di Variazioni VOD e Stream Resolvers
  vodProviders: [
    {
      id: "vixsrc",
      name: "VixSrc Primary",
      movieTemplate: "https://vixsrc.to/movie/{id}",
      tvTemplate: "https://vixsrc.to/tv/{id}/{season}/{episode}"
    },
    {
      id: "vixsrc_alt",
      name: "VixSrc Mirror",
      movieTemplate: "https://vixcloud.co/movie/{id}",
      tvTemplate: "https://vixcloud.co/tv/{id}/{season}/{episode}"
    }
  ]
};
