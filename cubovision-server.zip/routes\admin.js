// routes/admin.js
import { Router } from "express";
import { streamResolver } from "../services/streamResolver.js";
import { cacheService } from "../services/cacheService.js";

const router = Router();
const ADMIN_SECRET = process.env.ADMIN_SECRET_KEY || "cubovision_secret_admin_2009";

// Middleware di autenticazione per le operazioni di configurazione
function requireAdmin(req, res, next) {
  const token = req.headers["x-admin-token"] || req.query.secret;
  if (!token || token !== ADMIN_SECRET) {
    return res.status(403).json({ status: "error", message: "Non autorizzato: token errato" });
  }
  next();
}

// POST /api/admin/channels
// Aggiunge o aggiorna un canale con le sue variazioni
router.post("/channels", requireAdmin, (req, res) => {
  const channel = req.body;
  if (!channel || !channel.id || !channel.name) {
    return res.status(400).json({ status: "error", message: "Formato canale non valido (richiesti id, name)" });
  }

  const updated = streamResolver.addOrUpdateChannel(channel);
  res.json({ status: "ok", message: "Canale aggiornato", data: updated });
});

// POST /api/admin/sports
// Aggiunge o aggiorna un evento sportivo live con le sue variazioni (Server 1, Server 2, ecc.)
router.post("/sports", requireAdmin, (req, res) => {
  const sportEvent = req.body;
  if (!sportEvent || !sportEvent.id || !sportEvent.title) {
    return res.status(400).json({ status: "error", message: "Formato evento non valido (richiesti id, title)" });
  }

  const updated = streamResolver.addOrUpdateSport(sportEvent);
  cacheService.delete("external_sports_feed");
  res.json({ status: "ok", message: "Evento sportivo aggiornato", data: updated });
});

// POST /api/admin/variations
// Modifica specificamente la lista di variazioni di un canale o di un evento
router.post("/variations", requireAdmin, (req, res) => {
  const { type, id, variations } = req.body;
  if (!type || !id || !Array.isArray(variations)) {
    return res.status(400).json({ status: "error", message: "Richiesti type ('channel'|'sport'), id e array variations" });
  }

  const result = streamResolver.setVariations(type, id, variations);
  if (!result) {
    return res.status(404).json({ status: "error", message: "Elemento non trovato" });
  }

  res.json({ status: "ok", message: "Variazioni aggiornate", data: result });
});

// POST /api/admin/cache/clear
router.post("/cache/clear", requireAdmin, (req, res) => {
  cacheService.clear();
  res.json({ status: "ok", message: "Cache svuotata con successo" });
});

export default router;
